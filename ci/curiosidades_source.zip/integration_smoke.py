#!/usr/bin/env python3
"""Smoke real Go stages 2,4,5,6 + streaming Python stage3 against mocked local Ollama.
Network and TTS are mocked; rendering with Pillow/FFmpeg is REAL.
"""
import hashlib, http.server, json, os, pathlib, shutil, socketserver, subprocess, sys, tempfile, threading, wave, math, struct, time
BASE=pathlib.Path(__file__).resolve().parent
SRC=BASE/'CuriosidadesStudio_Modular_Fonte'
STEP3=BASE/'CuriosidadesStudio_Modular'/'03_Gerar_Roteiro_SEGURO.py'
GO='go'


def run(args, env=None, timeout=360, cwd=SRC):
    print('RUN:', ' '.join(map(str,args)),flush=True)
    p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
    print(p.stdout[-2500:],flush=True)
    if p.returncode: raise RuntimeError(f'Exit {p.returncode} in {args}: {p.stdout[-4000:]}')
    return p.stdout


def build_steps(build):
    for s in (2,4,5,6):
        run([GO,'build','-ldflags',f'-X main.stage={s}','-o',str(build/f'stage{s}'),'.'],timeout=90)

class Handler(http.server.BaseHTTPRequestHandler):
    story={}
    def log_message(self,*args): pass
    def do_GET(self):
        if self.path=='/api/tags':
            data=json.dumps({'models':[{'name':'qwen2.5:7b','model':'qwen2.5:7b'}]}).encode()
            self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        else:self.send_error(404)
    def do_POST(self):
        if self.path!='/api/generate':self.send_error(404);return
        content=json.dumps(self.story,ensure_ascii=False)
        self.send_response(200);self.send_header('Content-Type','application/x-ndjson');self.end_headers()
        for i in range(0,len(content),220):
            self.wfile.write((json.dumps({'response':content[i:i+220],'done':False},ensure_ascii=False)+'\n').encode())
        self.wfile.write(b'{"response":"","done":true}\n')
        self.wfile.flush()

def make_audio_tool(folder):
    fake=folder/'piper'
    fake.write_text('''#!/usr/bin/env python3
import sys,wave,math,struct
args=sys.argv;f=args[args.index('--output_file')+1]
text=sys.stdin.read();rate=22050
with wave.open(f,'wb') as w:
 w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate)
 frames=bytearray()
 for i in range(rate*2):
  sample=int(1800*math.sin(2*math.pi*220*i/rate))
  frames.extend(struct.pack('<h',sample))
 w.writeframes(frames)
print('TEST DOUBLE ONLY: synthesized tone, not actual TTS')
''')
    fake.chmod(0o755)


def main():
    with tempfile.TemporaryDirectory(prefix='cstudio_integration_') as d:
        t=pathlib.Path(d); proj=t/'PROJETO';proj.mkdir();bins=t/'bin';bins.mkdir();
        build_steps(bins);make_audio_tool(bins)
        env=os.environ.copy();env.update({'CSTUDIO_ROOT':str(proj),'CSTUDIO_TEST_SHORT':'1','PATH':str(bins)+os.pathsep+env['PATH']})
        top={'coletado':'2026-11-14T12:00:00-03:00','fonte':'fixture-de-teste (NAO TENDENCIAS REAIS)','top5':[
        {'titulo':'eclipse solar','buscas':'500K+','artigos':['Eclipse e ciencia']},
        {'titulo':'ciclone Brasil','buscas':'200K+'},
        {'titulo':'Lua e exploracao espacial','buscas':'100K+'},
        {'titulo':'tecnologia digital','buscas':'50K+'},
        {'titulo':'historia do Egito','buscas':'20K+'} ]}
        (proj/'01_top5_google_trends.json').write_text(json.dumps(top,ensure_ascii=False),encoding='utf-8')
        run([bins/'stage2'],env=env)
        selected=json.loads((proj/'02_tema_escolhido.json').read_text())
        assert selected['tendencia']['titulo']=='eclipse solar'
        sample=json.load(open(SRC/'assets/stories.json',encoding='utf8'))[0]
        story={k:v for k,v in sample.items()};story['topic']='Como funcionam eclipses e a Lua?';story['art']='earth'
        # Approx 550 words for stage3 schema validation; actual content is test fixture only.
        for scene in story['scenes']:
            base=scene['script']
            scene['script']=(' '.join([base]*3))[:2500]
        Handler.story=story
        class Server(socketserver.ThreadingTCPServer):allow_reuse_address=True
        # Stage3 hardcoded localhost:11434. If unavailable, fail explicitly instead of disrupting any real Ollama.
        try: server=Server(('127.0.0.1',11434),Handler)
        except OSError as e: raise RuntimeError('port 11434 already in use: integration mock cannot bind') from e
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            run([sys.executable,'-u',STEP3],env=env,timeout=120)
        finally:server.shutdown();server.server_close();thread.join(timeout=3)
        assert len(json.loads((proj/'03_roteiro.json').read_text())['scenes'])==6
        run([bins/'stage4'],env=env,timeout=150)
        previews=list((proj/'04_cenas').glob('*.png'))
        assert len(previews)==24,len(previews)
        run([bins/'stage5'],env=env,timeout=90)
        wavs=list((proj/'05_audios').glob('voz_??.wav'))
        assert len(wavs)==6,len(wavs)
        for i,sc in enumerate(story['scenes']):
            f=proj/'05_audios'/f'voz_{i:02d}.wav'
            assert (pathlib.Path(str(f)+'.texto.sha256')).read_text()==hashlib.sha256(sc['script'].encode()).hexdigest()
        run([bins/'stage6'],env=env,timeout=300)
        finals=list((proj/'06_video_final').glob('*_animado_2d.mp4'))
        assert len(finals)==1,finals
        probe=subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(finals[0])],text=True)
        dur=float(probe.strip())
        assert 10<dur<40,dur
        assert finals[0].stat().st_size>100000
        print('PASS: stages 02->03(mock Ollama)->04(real previews)->05(mock Piper)->06(real FFmpeg); MP4 length',dur,'size',finals[0].stat().st_size)
        print('WARN: Stage 01 Google Trends, real Ollama, real Piper, Windows launcher not executed in this test')

if __name__=='__main__':
    try:main()
    except Exception as e:print('FAIL:',repr(e),file=sys.stderr);raise
