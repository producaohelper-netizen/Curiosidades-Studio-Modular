package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

var stepNames = []string{"Google Trends", "Escolha editorial", "Roteiro Ollama", "Cenas ilustradas", "Narração Piper", "Vídeo final"}

func appDir() (string, error) {
	exe, err := os.Executable()
	if err != nil {
		return "", err
	}
	return filepath.Dir(exe), nil
}
func run(base string, index int, log io.Writer) error {
	suffix := ""
	if runtime.GOOS == "windows" {
		suffix = ".exe"
	}
	filename := filepath.Join(base, fmt.Sprintf("0%d_%s%s", index, []string{"Google_Trends", "Escolher_Tema", "Gerar_Roteiro", "Gerar_Cenas", "Gerar_Audio", "Montar_Video"}[index-1], suffix))
	var c *exec.Cmd
	if index == 3 {
		script := filepath.Join(base, "03_Gerar_Roteiro_SEGURO.py")
		if _, err := os.Stat(script); err != nil {
			return fmt.Errorf("etapa 03 segura ausente: %w", err)
		}
		py := os.Getenv("CSTUDIO_PYTHON")
		if py == "" {
			if runtime.GOOS == "windows" {
				py = "py"
			} else {
				py = "python3"
			}
		}
		args := []string{"-u", script}
		if py == "py" {
			args = []string{"-3", "-u", script}
		}
		c = exec.Command(py, args...)
	} else {
		if _, err := os.Stat(filename); err != nil {
			return fmt.Errorf("modulo %02d ausente: %s", index, filename)
		}
		c = exec.Command(filename)
	}
	c.Dir = base
	c.Stdout = io.MultiWriter(os.Stdout, log)
	c.Stderr = io.MultiWriter(os.Stderr, log)
	// Original stage EXEs prompt Enter after success, so supply only one newline.
	c.Stdin = strings.NewReader("\n")
	if err := c.Run(); err != nil {
		return fmt.Errorf("etapa %d (%s): %w", index, stepNames[index-1], err)
	}
	return nil
}
func execute(base string, log io.Writer) error {
	fmt.Fprintln(log, "Iniciando producao", time.Now().Format(time.RFC3339))
	for i := 1; i <= 6; i++ {
		start := time.Now()
		fmt.Printf("\n===== ETAPA %d/6: %s =====\n", i, stepNames[i-1])
		fmt.Fprintf(log, "\n===== ETAPA %d/6: %s =====\n", i, stepNames[i-1])
		if os.Getenv("CSTUDIO_SKIP_TRENDS_TEST") == "1" && i == 1 {
			fixture := filepath.Join(base, "PROJETO", "01_top5_google_trends.json")
			if _, err := os.Stat(fixture); err != nil {
				return errors.New("fixture de Trends ausente em modo de teste")
			}
			fmt.Fprintln(log, "Aviso: Google Trends SIMULADO. Somente teste.")
			continue
		}
		if err := run(base, i, log); err != nil {
			return err
		}
		fmt.Fprintf(log, "Etapa %d concluida em %s\n", i, time.Since(start).Round(time.Second))
	}
	return nil
}
func main() {
	base, err := appDir()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	project := filepath.Join(base, "PROJETO")
	if value := os.Getenv("CSTUDIO_ROOT"); value != "" {
		project = value
	}
	if err := os.MkdirAll(filepath.Join(project, "LOGS"), 0755); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	file, err := os.Create(filepath.Join(project, "LOGS", time.Now().Format("20060102_150405")+"_executor.log"))
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer file.Close()
	err = execute(base, file)
	if err != nil {
		fmt.Fprintf(os.Stderr, "\nFALHA. Nao foi gerado video final aprovado: %v\n", err)
		fmt.Fprintf(file, "FALHA: %v\n", err)
		if os.Getenv("CSTUDIO_NO_PAUSE") != "1" {
			fmt.Println("Pressione ENTER para fechar.")
			bufio.NewReader(os.Stdin).ReadString('\n')
		}
		os.Exit(1)
	}
	fmt.Println("\nTodas as etapas concluidas. Verifique o arquivo MP4 antes de publicar.")
	if os.Getenv("CSTUDIO_NO_PAUSE") != "1" {
		fmt.Println("Pressione ENTER para fechar.")
		bufio.NewReader(os.Stdin).ReadString('\n')
	}
}
