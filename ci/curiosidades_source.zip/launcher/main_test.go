package main

import (
	"bytes"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

func writeStub(t *testing.T, dir string, step int, fail bool) {
	t.Helper()
	suffix := ""
	if runtime.GOOS == "windows" {
		suffix = ".exe"
	}
	if runtime.GOOS == "windows" {
		t.Skip("Unix shell script stubs only")
	}
	names := []string{"Google_Trends", "Escolher_Tema", "Gerar_Roteiro", "Gerar_Cenas", "Gerar_Audio", "Montar_Video"}
	if step == 3 {
		return
	}
	target := filepath.Join(dir, "0"+string(rune('0'+step))+"_"+names[step-1]+suffix)
	code := "#!/bin/sh\necho " + string(rune('0'+step)) + " >> \"$MOCK_COUNTER\"\n"
	if fail {
		code += "exit 3\n"
	}
	if err := os.WriteFile(target, []byte(code), 0755); err != nil {
		t.Fatal(err)
	}
}
func TestPipelineOrderAndStop(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Linux integration test; Windows CI uses built EXE")
	}
	for _, stop := range []int{0, 2, 5} {
		dir := t.TempDir()
		counter := filepath.Join(dir, "counter.txt")
		t.Setenv("MOCK_COUNTER", counter)
		t.Setenv("CSTUDIO_PYTHON", "python3")
		t.Setenv("CSTUDIO_SKIP_TRENDS_TEST", "")
		for s := 1; s <= 6; s++ {
			writeStub(t, dir, s, s == stop)
		}
		py := "from pathlib import Path\nimport os\np=Path(os.environ['MOCK_COUNTER']);p.write_text(p.read_text()+'3\\n' if p.exists() else '3\\n')\n"
		if err := os.WriteFile(filepath.Join(dir, "03_Gerar_Roteiro_SEGURO.py"), []byte(py), 0644); err != nil {
			t.Fatal(err)
		}
		var log bytes.Buffer
		err := execute(dir, &log)
		if (err != nil) != (stop != 0) {
			t.Fatalf("stop=%d err=%v", stop, err)
		}
		raw, e := os.ReadFile(counter)
		if e != nil {
			t.Fatal(e)
		}
		got := strings.TrimSpace(string(raw))
		want := "1\n2\n3\n4\n5\n6"
		if stop > 0 {
			want = strings.Join(strings.Split(want, "\n")[:stop], "\n")
		}
		if got != want {
			t.Fatalf("stop=%d got=%q want=%q", stop, got, want)
		}
	}
}
