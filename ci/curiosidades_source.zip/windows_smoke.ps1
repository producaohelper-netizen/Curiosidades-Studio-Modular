$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'CuriosidadesStudio_Modular_Fonte'
$project = Join-Path $env:RUNNER_TEMP 'CStudioProject'
New-Item -ItemType Directory -Force $project | Out-Null
$env:CSTUDIO_ROOT = $project
Push-Location $src
try {
  go test -v ./...
  if ($LASTEXITCODE -ne 0) { throw 'go test failed' }
  go build -ldflags '-X main.stage=2' -o (Join-Path $env:RUNNER_TEMP '02_Escolher_Tema.exe') .
  if ($LASTEXITCODE -ne 0) { throw 'Windows build failed' }
} finally { Pop-Location }
$top = @{
 coletado = '2026-11-14T12:00:00-03:00'
 fonte = 'fixture de teste, nao Google Trends'
 top5 = @(
  @{titulo='eclipse solar';buscas='500K+';artigos=@('Eclipse')} ,
  @{titulo='ciclone Brasil';buscas='200K+'},
  @{titulo='Lua e astronomia';buscas='100K+'},
  @{titulo='internet';buscas='50K+'},
  @{titulo='historias do Egito';buscas='20K+'}
 )
}
$top | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 (Join-Path $project '01_top5_google_trends.json')
# The Go program asks for Enter at end. Inject newline through stdin.
"`n" | & (Join-Path $env:RUNNER_TEMP '02_Escolher_Tema.exe')
if ($LASTEXITCODE -ne 0) { throw 'Stage 02 failed on Windows' }
$out = Join-Path $project '02_tema_escolhido.json'
if (!(Test-Path $out)) { throw 'Stage 02 missing output' }
$json = Get-Content $out -Raw -Encoding UTF8 | ConvertFrom-Json
if ($json.tendencia.titulo -ne 'eclipse solar') { throw "Unexpected result: $($json.tendencia.titulo)" }
Write-Host 'PASS Windows: unit tests, build, stage 02 native .exe, JSON contract.'
Write-Warning 'Not tested on Windows here: external RSS, real Ollama/Piper, full video, orchestration EXE.'
