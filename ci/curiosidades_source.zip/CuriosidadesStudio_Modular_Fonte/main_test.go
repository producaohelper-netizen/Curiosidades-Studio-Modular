package main
import (
  "testing"
  "encoding/json"
  "os"
  "path/filepath"
)
func TestTrafficCount(t *testing.T) {tests:=map[string]float64{"200K+":200000,"1M+":1000000,"2.5K+":2500,"500+":500};for s,want:=range tests {got:=trafficCount(s);if got!=want {t.Errorf("%q expected %v, got %v",s,want,got)}}}
func TestEditorialScore(t *testing.T){if score(Trend{Title:"ciclone no Brasil",Traffic:"100K+"})<=score(Trend{Title:"tragédia com vítimas",Traffic:"500K+"}){t.Fatal("safety score incorrect")}}
func TestAssetsStories(t *testing.T){b,e:=assets.ReadFile("assets/stories.json");if e!=nil{t.Fatal(e)};var ss []Story;if e=json.Unmarshal(b,&ss);e!=nil{t.Fatal(e)};if len(ss)<6{t.Fatal("missing reference stories")}}
func TestJSONRoundTrip(t *testing.T){tmp:=t.TempDir();root=tmp;want:=Selection{Trend:Trend{Title:"Lua"},Theme:"Lua"};if e:=writeJSON("test.json",want);e!=nil{t.Fatal(e)};var got Selection;if e:=readJSON("test.json",&got);e!=nil{t.Fatal(e)};if got.Theme!=want.Theme{t.Fatal("mismatch")};if _,e:=os.Stat(filepath.Join(tmp,"test.json"));e!=nil{t.Fatal(e)}}
