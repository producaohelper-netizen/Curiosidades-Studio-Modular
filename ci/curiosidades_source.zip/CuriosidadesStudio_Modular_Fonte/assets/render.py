"""Curiosidades Studio 2D — original animated explainers, scene-specific action choreography.
No stock downloads and no third-party copyrighted art. Narration is mandatory in release mode.
"""
import os,sys,json,math,random,subprocess,argparse,re,wave,struct,time
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
W,H=960,540
COL={'ink':'#243449','white':'#ffffff','red':'#ef6262','blue':'#568bd9','yellow':'#ffca66','green':'#50b7a6','gray':'#8494a4'}
PALETTES={'earth':('#d8edf9','#fff2d6'),'moon':('#e6e7fa','#fff4e4'),'octopus':('#bcebe6','#e3f6f5'),'lightning':('#e1eafa','#fff4cd'),'volcano':('#ffe5d9','#fff0e3'),'brain':('#f9dff2','#e9f1ff'),'pyramid':('#f9e6c7','#fff5da'),'network':('#dceefa','#e4f8ed')}
FONT_DIRS=['/usr/share/fonts/truetype/dejavu','C:/Windows/Fonts']
def font(n,b=True):
    names=(['DejaVuSans-Bold.ttf','arialbd.ttf'] if b else ['DejaVuSans.ttf','arial.ttf'])
    for folder in FONT_DIRS:
        for name in names:
            p=os.path.join(folder,name)
            if os.path.isfile(p):return ImageFont.truetype(p,n)
    return ImageFont.load_default()
FF={}
def f(n,b=True):
    k=(n,b)
    if k not in FF:FF[k]=font(n,b)
    return FF[k]
def blend(a,b,t):return tuple(round(x*(1-t)+y*t) for x,y in zip(a,b))
def hexrgb(s):return tuple(bytes.fromhex(s.lstrip('#')))
def rr(d,b,fill,rad=15,outline=None,width=3):d.rounded_rectangle(tuple(int(v) for v in b),radius=rad,fill=fill,outline=outline,width=width)
def ell(d,b,fill,outline=COL['ink'],width=4):d.ellipse(tuple(int(v) for v in b),fill=fill,outline=outline,width=width)
def poly(d,pts,fill,outline=COL['ink'],width=4):
    pts=[(int(x),int(y)) for x,y in pts]
    d.polygon(pts,fill=fill)
    if outline:d.line(pts+[pts[0]],fill=outline,width=width,joint='curve')
def ln(d,pts,fill=COL['ink'],width=5):d.line([(int(x),int(y)) for x,y in pts],fill=fill,width=width,joint='curve')
def text(d,xy,s,size=22,color=COL['ink'],bold=True):d.text((int(xy[0]),int(xy[1])),str(s),font=f(size,bold),fill=color,stroke_width=0)
def center(d,y,s,size=27,color=COL['ink']):
    bb=d.textbbox((0,0),s,font=f(size));text(d,((W-(bb[2]-bb[0]))/2,y),s,size,color)
def arrow(d,x1,y1,x2,y2,c=COL['red'],width=7):
    ln(d,[(x1,y1),(x2,y2)],c,width);a=math.atan2(y2-y1,x2-x1);length=19
    poly(d,[(x2,y2),(x2-length*math.cos(a-.48),y2-length*math.sin(a-.48)),(x2-length*math.cos(a+.48),y2-length*math.sin(a+.48))],c,None)
def cloud(d,x,y,scale=1):
    for dx,dy,r in [(-45,10,33),(-16,-12,40),(22,0,38),(48,15,28)]:
        ell(d,(x+(dx-r)*scale,y+(dy-r)*scale,x+(dx+r)*scale,y+(dy+r)*scale),'#ffffff',None)
    rr(d,(x-80*scale,y,x+82*scale,y+31*scale),'#ffffff',15)
def star(d,x,y,size=10,color='#ffcf68'):
    pts=[]
    for j in range(10):
        a=2*math.pi*j/10-math.pi/2;r=size if j%2==0 else size*.35
        pts.append((x+math.cos(a)*r,y+math.sin(a)*r))
    poly(d,pts,color,None)
def person(d,x,y,scale=1,pose='stand',phase=0,look=1):
    """Simple hinged puppet. Coordinates represent feet; arms/legs animate independently."""
    sway=math.sin(phase*2*math.pi)
    if pose in ('walk','run'):
        x+=sway*8*scale
        step=sway*(27 if pose=='run' else 17)*scale
    else: step=0
    jump=(max(0,math.sin(phase*math.pi))*32 if pose=='jump' else 0)*scale
    y-=jump
    skin='#ffcc9d';shirt='#f06d75';pants='#466d9b';ink=COL['ink']
    head=(x-22*scale,y-188*scale,x+22*scale,y-143*scale)
    ln(d,[(x-9*scale,y-79*scale),(x-13*scale-step,y-17*scale)],ink,max(3,int(10*scale)))
    ln(d,[(x+9*scale,y-79*scale),(x+13*scale+step,y-17*scale)],ink,max(3,int(10*scale)))
    ell(d,(x-25*scale-step,y-19*scale,x-4*scale-step,y-10*scale),'#42526b',None)
    ell(d,(x+4*scale+step,y-19*scale,x+25*scale+step,y-10*scale),'#42526b',None)
    rr(d,(x-22*scale,y-141*scale,x+22*scale,y-77*scale),shirt,max(5,int(12*scale)),ink,max(2,int(3*scale)))
    if pose=='surprise':handy=y-177*scale
    elif pose=='point':handy=y-146*scale
    elif pose=='run':handy=y-95*scale-10*sway*scale
    else:handy=y-101*scale+5*sway*scale
    ln(d,[(x-20*scale,y-131*scale),(x-45*scale,y-(110+(25 if pose=='surprise' else 0))*scale)],skin,max(3,int(10*scale)))
    ln(d,[(x+20*scale,y-131*scale),(x+43*scale,y-(130 if pose in ('point','surprise') else 102)*scale)],skin,max(3,int(10*scale)))
    ell(d,head,skin,ink,max(2,int(3*scale)))
    # hair fringe and animated eyebrows
    d.arc((x-24*scale,y-196*scale,x+25*scale,y-155*scale),180,350,fill='#51352c',width=max(3,int(10*scale)))
    for dx in [-8,9]:ell(d,(x+(dx-2)*scale,y-172*scale,x+(dx+1)*scale,y-168*scale),ink,None)
    if pose=='surprise':ell(d,(x-5*scale,y-160*scale,x+5*scale,y-148*scale),'#ad5860',None)
    else:d.arc((x-10*scale,y-160*scale,x+12*scale,y-145*scale),0,160,fill='#9a4b4f',width=max(2,int(2*scale)))
def bus(d,x,y,scale=1,phase=0):
    dx=math.sin(phase*math.pi*2)*3
    x+=dx
    rr(d,(x,y-112*scale,x+250*scale,y+5*scale),'#ffd46c',21,COL['ink'],4)
    rr(d,(x+22*scale,y-93*scale,x+225*scale,y-41*scale),'#a9e1f0',9,COL['ink'],3)
    for j in range(1,4):ln(d,[(x+(22+j*50)*scale,y-93*scale),(x+(22+j*50)*scale,y-41*scale)],width=3)
    for dx1 in [48,199]:ell(d,(x+(dx1-22)*scale,y-20*scale,x+(dx1+22)*scale,y+24*scale),'#41516b',COL['ink'],3)
def earth(d,x,y,r=125,angle=0):
    ell(d,(x-r,y-r,x+r,y+r),'#61ace2','#1d5579',5)
    c=math.sin(angle)*r*.16
    poly(d,[(x-55+c,y-55),(x-19+c,y-80),(x+19+c,y-58),(x-1+c,y-30),(x+22+c,y+8),(x-9+c,y+39),(x-45+c,y+21),(x-70+c,y-18)],'#79c883',None)
    poly(d,[(x+35-c,y+17),(x+71-c,y-4),(x+84-c,y+34),(x+61-c,y+77),(x+29-c,y+92),(x+15-c,y+45)],'#83ce8b',None)
    for v in (-33,43):d.arc((x-r+17,y+v-r/2,x+r-17,y+v+r/2),5,175,fill='#ecfaff',width=3)
def moon(d,x,y,r=120):
    ell(d,(x-r,y-r,x+r,y+r),'#e1e7e8','#5f7689',4)
    for dx,dy,sz in [(-48,-34,23),(49,-58,17),(-13,51,29),(72,49,13)]:ell(d,(x+dx-sz,y+dy-sz,x+dx+sz,y+dy+sz),'#b5c3c8',None)
def octopus(d,x,y,phase=0,scale=1):
    for i in range(8):
        a=math.pi*i/7+0.1;tx=x+(i-3.5)*35*scale;ty=y+70*scale+math.sin(phase*math.tau+i)*20*scale
        ln(d,[(x,y+25*scale),(x+(i-3.5)*16*scale,y+60*scale),(tx,ty)],'#c467b1',max(5,int(13*scale)))
    ell(d,(x-83*scale,y-100*scale,x+83*scale,y+50*scale),'#dd82c3','#7d427c',4)
    for dx in [-29,33]:ell(d,(x+(dx-7)*scale,y-34*scale,x+(dx+7)*scale,y-20*scale),'#263d52',None)
    d.arc((x-22*scale,y-17*scale,x+22*scale,y+22*scale),0,170,fill='#684166',width=4)
def volcano(d,x,y,phase,active=True):
    poly(d,[(x-220,y+110),(x-87,y-110),(x-37,y-85),(x+30,y-120),(x+200,y+110)],'#997879')
    poly(d,[(x-93,y-101),(x-37,y-84),(x+27,y-114),(x+39,y-78),(x-27,y-53)],'#f39e59',None)
    if active:
        ln(d,[(x-21,y-68),(x+15,y+55),(x-19,y+112)],'#ff9c42',16)
        for j in range(6):
            xx=x+(j-3)*24+math.sin(phase*6+j)*12; yy=y-150-(j%3)*23-(phase*18)%27
            ell(d,(xx-21,yy-15,xx+21,yy+15),'#b9abae',None)
def bolt(d,x,y,phase):
    cloud(d,x,y-100,1.0)
    if phase>.1:
        poly(d,[(x+15,y-80),(x-18,y+23),(x+14,y+14),(x-17,y+120),(x+69,y-1),(x+31,y+6),(x+53,y-80)],'#ffcb44','#d8951f',3)
def pyramid(d,x,y,phase=0,building=False):
    poly(d,[(x-192,y+100),(x,y-185),(x+199,y+100)],'#efc67c')
    poly(d,[(x,y-185),(x+199,y+100),(x+20,y+100)],'#d5a66a',None)
    for v in range(0,7):
        yy=y-130+v*36; dx=(yy-(y-185))*.68
        ln(d,[(x-dx,yy),(x+dx,yy)],'#c29b66',2)
    if building:
        rr(d,(x+155+math.sin(phase*math.tau)*15,y+50,x+206+math.sin(phase*math.tau)*15,y+91),'#c59459',3)
def brain(d,x,y,phase=0):
    ell(d,(x-120,y-80,x+120,y+95),'#f3a6cf','#ad6a9d',4)
    for j in range(10):
        xx=x+math.cos(j*2.45)*66; yy=y+math.sin(j*2.45)*40
        d.arc((xx-23,yy-23,xx+28,yy+29),35,250,fill='#c56b9d',width=5)
    ln(d,[(x,y-70),(x,y+86)],'#c46b9d',4)
def phone(d,x,y,scale=1):
    rr(d,(x-51*scale,y-94*scale,x+51*scale,y+94*scale),'#2c415b',12)
    rr(d,(x-40*scale,y-75*scale,x+40*scale,y+61*scale),'#d0f2f6',6)
    ell(d,(x-5*scale,y+73*scale,x+5*scale,y+83*scale),'#96c9da',None)
def wifi(d,x,y,phase=0):
    for i in range(3):d.arc((x-28-i*28,y-28-i*28,x+28+i*28,y+28+i*28),215,324,fill='#1e9aaf',width=6)
    ell(d,(x-7,y+14,x+7,y+28),'#1e9aaf',None)
def layout(story,sc,ix,shot,u):
    art=story['art'];p1,p2=PALETTES.get(art,('#e6f1f5','#fff7e5'))
    im=Image.new('RGB',(W,H),p1);d=ImageDraw.Draw(im)
    d.rectangle((0,0,W,H),fill=p1)
    # editorial cutout background: not a static techno dashboard
    d.ellipse((-120,210,460,770),fill=p2)
    d.ellipse((760,-180,1200,290),fill=blend(hexrgb(p1),hexrgb(p2),.42))
    for k in range(11):
        xx=45+k*92;d.ellipse((xx,440,xx+3,443),fill='#cad8de')
    # scene header is small; emphasis is on animated action
    rr(d,(26,18,200,51),'#243449',10)
    text(d,(40,25),'CURIOSIDADES 2D',14,'#ffffff')
    rr(d,(807,19,932,51),'#ffffff',10)
    text(d,(821,26),f'{ix+1:02} / {len(story["scenes"]):02}',14)
    headline=sc['headline']
    if len(headline)>31:headline=headline[:30]+'…'
    text(d,(38,69),headline,30 if len(headline)<29 else 26)
    # stage, different 'action shot' per scene, not just 3 static cards
    d.line((40,417,921,417),fill='#bed0cf',width=4)
    phase=u
    b=ix
    if art=='earth':
        speech=(sc.get('script','')+' '+sc.get('headline','')).lower()
        explicit=sc.get('visual_kind','')
        if explicit in ('rotation','inertia','ocean','day','slow'):kind=explicit
        elif any(x in speech for x in ('ônibus','onibus','inércia','inercia','freia','freada instantânea')):
            kind='inertia'
        elif any(x in speech for x in ('oceano','oceanos','correntes','água','atmosfera','vento')) and not any(x in speech for x in ('ônibus','onibus','inércia')):
            kind='ocean'
        elif any(x in speech for x in ('dia e noite','luz do sol','sol','noite','ciclo solar')):
            kind='day'
        elif any(x in speech for x in ('desaceleração','desacelerasse','devagar','lenta','milhões de anos','milhares de anos')):
            kind='slow'
        else:kind='rotation'
        # Draw an actual visual metaphor for the corresponding chapter, not the
        # same static planet in all scenes. All artwork is generated locally.
        if kind=='inertia':
            d.rectangle((0,329,W,421),fill='#d7e2ea')
            for q in range(11):
                xx=q*115-int(u*90);ln(d,[(xx,416),(xx+66,416)],'#a3b7c8',3)
            bx=115+95*(1-u) if shot in (0,3) else 215+25*(1-u)
            bus(d,bx,328,1.55,u)
            person(d,743+68*u,418,1.05,'surprise' if shot!=0 else 'stand',u)
            arrow(d,642,191,782,191)
            if shot==3:text(d,(620,291),'O CORPO CONTINUA!',21,'#da604e')
        elif kind=='ocean':
            d.rectangle((0,323,W,420),fill='#66b9d2')
            for q in range(9):
                x=-88+q*134+20*math.sin(2*math.pi*u+q)
                d.arc((x,316+q%3*17,x+140,378+q%3*17),190,340,fill='#e2faff',width=7)
            poly(d,[(0,412),(0,320),(100,310),(200,342),(270,350),(380,418)],'#cab681',None)
            for q in range(3):cloud(d,220+q*225+u*40,180+q%2*25,.38)
            person(d,265,410,.75,'surprise',u)
            arrow(d,477,270,771,270,'#f07e64',11)
            text(d,(490,314),'AR + ÁGUA EM MOVIMENTO',20,'#28567c')
        elif kind=='day':
            d.rectangle((0,141,W,417),fill='#45598b')
            for q in range(15):star(d,65+q*59,176+(q%4)*48,3,'#ffffff')
            ell(d,(55,185,220,350),'#ffcd63',None)
            for q in range(8):
                a=q*math.pi/4; cx=137;cy=268
                ln(d,[(cx+95*math.cos(a),cy+95*math.sin(a)),(cx+118*math.cos(a),cy+118*math.sin(a))],'#ffda84',4)
            earth(d,555+u*15,290,126,u*3)
            arrow(d,233,260,415,260,'#ffdfa4',8)
            person(d,811,412,.65,'point',u)
        elif kind=='slow':
            earth(d,377,290,123,u*.4)
            # Large clock and curved speed indicator emphasize a gradual change.
            ell(d,(675,200,855,380),'#ffffff','#4c7798',5)
            d.arc((688,213,842,367),200,330,fill='#64a8be',width=7)
            ln(d,[(766,289),(766+53*math.sin(u*math.tau/8),289-53*math.cos(u*math.tau/8))],'#e48f62',7)
            ln(d,[(766,289),(766+30*math.sin(u*math.tau/3),289-30*math.cos(u*math.tau/3))],width=5)
            for q in range(12):
                a=q*math.tau/12
                ell(d,(766+72*math.sin(a)-3,289-72*math.cos(a)-3,766+72*math.sin(a)+3,289-72*math.cos(a)+3),'#8097a5',None)
            arrow(d,530,288,645,288,'#e8ad66')
            text(d,(665,392),'DEVAGAR...',20,'#3e7090')
        else:
            earth(d,410+u*18,280,124,u*1.2)
            person(d,734,419,.88,'surprise' if b==0 else 'point',u)
            arrow(d,570,282,687,282)
            if b==1:text(d,(585,160),'1.670 km/h',27,'#d75b46')
    elif art=='octopus':
        d.rectangle((0,395,W,435),fill='#9ddcd8')
        for k in range(7):ell(d,(k*144+60,105+(k%3)*40,k*144+70,115+(k%3)*40),'#d9f8f8',None)
        octopus(d,420+22*math.sin(u*math.tau),305,u,1.2)
        if b in (0,1,2):
            for q in range(3):
                x=675+(q%2)*64;y=190+q*68
                ell(d,(x,y,x+39,y+36),'#e95577',None)
                text(d,(x+8,y+4),'♥',22,'#ffffff')
        elif b==4:
            rr(d,(658,244,834,319),'#a9dbb5',13);text(d,(672,266),'CAMUFLAGEM',16)
        else:arrow(d,635,290,740,265)
    elif art=='lightning':
        bolt(d,404,261,max(.12,u))
        person(d,705,417,.86,'surprise' if b in (0,4) else 'point',u)
        if b==3: text(d,(654,187),f'{1+int(u*4)}... 2... 3...',23,'#e18a45')
        elif b==1:arrow(d,523,230,647,210,'#dfb030')
        elif b==2:arrow(d,522,309,642,326,'#6da2d0')
        elif b==5:rr(d,(675,302,810,330),'#e9a6a4',12);text(d,(685,307),'ABRIGUE-SE',14)
    elif art=='brain':
        # beds/pillow with sleeping figure
        rr(d,(182,324,609,405),'#c3d4e6',22)
        rr(d,(210,324,310,383),'#ffffff',20)
        person(d,350,375,.66,'stand',u)
        brain(d,691,258,u)
        for k in range(3):star(d,584+k*63,145+(k%2)*24,9)
        if b==3:text(d,(565,365),'Z z z...',24,'#b36da0')
        if b==1:arrow(d,560,262,630,262,'#bb6fa6')
    elif art=='volcano':
        volcano(d,440,325,u,b not in (1,2))
        person(d,744,417,.86,'surprise' if b in (0,3) else 'point',u)
        if b==1:
            rr(d,(680,209,815,252),'#f4b66e',15);text(d,(690,219),'MAGMA',20)
        if b==2:
            arrow(d,620,355,694,355,'#d4775b');arrow(d,800,355,730,355,'#d4775b')
    elif art=='moon':
        d.rectangle((0,344,W,417),fill='#c8d9bd')
        moon(d,345+math.sin(u*math.pi)*7,240,117)
        person(d,731+u*10,417,.88,'point',u)
        if b==3:arrow(d,694,234,570,234,'#d77a54')
        if b==2:text(d,(525,170),'384.400 km',29,'#6d72b6')
        if b==1:rr(d,(590,326,675,372),'#ffffff',8)
    elif art=='network':
        phone(d,317,268,1.25);phone(d,716,268,1.05)
        for k in range(5):
            x=424+k*57;y=269+38*math.sin(u*math.pi*2+k)
            rr(d,(x,y,x+31,y+29),'#f9c767',6)
        if b==2:
            d.rectangle((0,372,W,420),fill='#97d9e4')
            ln(d,[(395,373),(470,385),(635,396),(700,373)],'#315b76',6)
        wifi(d,317,135,u);wifi(d,716,135,u)
        if b==4: text(d,(510,356),'TRÂNSITO!',21,'#df7464')
    elif art=='pyramid':
        d.rectangle((0,387,W,419),fill='#e0bd84')
        pyramid(d,431,311,u,b in (1,2,3))
        person(d,732+u*18,419,.72,'walk' if b in (1,2,3) else 'point',u)
        if b==2:
            rr(d,(605+u*70,337,689+u*70,387),'#d9b16f',6)
            arrow(d,688,324,755,310,'#c67452')
        elif b==4:
            d.arc((591,245,780,410),240,360,fill='#cc965d',width=5)
    # Camera direction: every chapter uses four distinct framings, not four stationary title cards.
    # Action poses keep moving in every shot; closeups make the narrative legible on mobile.
    if shot in (1, 2):
        top, bottom = 146, 418
        camera_x = 394 if shot == 1 else 654
        zoom = 1.36 if shot == 1 else 1.27
        cropw = int(W / zoom)
        crop_h = int((bottom-top) / zoom)
        cx = camera_x + int(math.sin(phase*math.pi*2)*13)
        left = max(0,min(W-cropw,cx-cropw//2))
        upper = max(134,min(418-crop_h,270-crop_h//2))
        cut=im.crop((left,upper,left+cropw,upper+crop_h)).resize((W,bottom-top),Image.Resampling.BILINEAR)
        im.paste(cut,(0,top))
        d=ImageDraw.Draw(im)
        # Scene-specific motion cue appears only on the close shot.
        if shot==1:
            for q in range(3):
                start=160+q*30+math.sin(phase*math.tau)*5
                ln(d,[(start,361+q*13),(start+76,361+q*13)],'#ffffff',3)
    elif shot==3:
        # Return to wide composition for the payoff; a brief cartoon reaction beat.
        star(d,839+11*math.sin(phase*math.tau),204,20,'#ffbd56')
        star(d,795,174+8*math.cos(phase*math.tau),9,'#ffbd56')
    # scene-specific action labels chosen from exact headline to keep relevance
    labels={'earth':[['PARE AGORA?!','ROTAÇÃO','CONTINUA','HIPÓTESE'],['VELOCIDADE','CHÃO EM MOVIMENTO','JUNTOS','SEM PERCEBER'],['O ÔNIBUS FREIA','INÉRCIA','O CORPO SEGUE','MESMA IDEIA'],['FREIO LENTO','SEM O TRANCO','OUTRO CENÁRIO','CLIMA MUDA'],['SOL E TERRA','ROTAÇÃO PAROU','MESES DE LUZ','DIAS DIFERENTES'],['AINDA GIRA','DIA E NOITE','BOA NOTÍCIA','FIM']],
    'octopus':[['TRÊS CORAÇÕES','NÃO É BRINCADEIRA','OLHA ISSO!','NATUREZA'],['DOIS CORAÇÕES','BRÂNQUIAS','OXIGÊNIO','CIRCULAÇÃO'],['UM CORAÇÃO','RESTO DO CORPO','SANGUE','TRABALHO EM EQUIPE'],['NADAR CANSA','O CORAÇÃO MUDA','ESFORÇO','DESCANSO'],['TROCA A COR','SE ESCONDE','CAMUFLAGEM','TEXTURA'],['OCEANO','SURPRESAS','ANIMAIS','FIM']],
    'lightning':[['RELÂMPAGO!','E O TROVÃO?','DUAS COISAS','TCHAAAM!'],['A LUZ','CHEGA PRIMEIRO','MUITO RÁPIDA','CLARÃO'],['O SOM','VEM DEPOIS','MAIS LENTO','ESTRONDO'],['CONTANDO','SEGUNDOS','ATENÇÃO','SEGURANÇA'],['O AR AQUECE','EXPANDE','TROVÃO','BUM!'],['TEM TROVÃO?','ABRIGO!','NÃO SE EXPONHA','SEGURANÇA']],
    'brain':[['DORMIU?','CÉREBRO ACORDADO','TRABALHANDO','DURMA BEM'],['MEMÓRIAS','APRENDIZADO','ORGANIZANDO','NO SONO'],['SEU CORPO','REPAROS','DESCANSO','ENERGIA'],['SONHOS','IMAGINAÇÃO','ENQUANTO DORME','MISTÉRIO'],['CADA IDADE','TEM SUA META','SONO IMPORTA','ROTINA'],['DORMIR BEM','É SAÚDE','CUIDADO','BOA NOITE']],
    'volcano':[['ERUPÇÃO!','ROCHA QUENTE','GASES','NA TERRA'],['MAGMA','LAVA','DENTRO','FORA'],['PLACAS','MOVIMENTO','CROSTA','TERRA'],['GASES','PRESSÃO','EXPANSÃO','ERUPÇÃO'],['VULCÕES','TIPOS','LAVA OU CINZA','DIFERENTES'],['PLANETA VIVO','MUDANÇAS','CIÊNCIA','FIM']],
    'moon':[['ME SEGUE?','NA JANELA','QUE ESTRANHO!','É A LUA'],['PERTO','LONGE','DISTÂNCIA','PERSPECTIVA'],['MUITO LONGE','384 MIL KM','QUASE PARADA?','APARENTE'],['OLHE O DEDO','TAMPE UM OLHO','MUDE O OLHO','EXPERIMENTE'],['LUA SE MOVE','MUITO DISTANTE','PARECE LENTA','RELATIVO'],['MISTÉRIO','RESOLVIDO','DISTÂNCIA','FIM']],
    'network':[['MENSAGEM!','INTERNET','CAMINHO','VOCÊ SABIA?'],['WI-FI','ROTEADOR','PRIMEIRO PASSO','SINAL'],['OCEANO','CABOS','DADOS VIAJAM','CONECTADOS'],['PEDAÇOS','PACOTES','VÃO E VOLTAM','INFORMAÇÃO'],['CONGESTIONOU!','FILA DIGITAL','DEMORA','PACOTE ATRASADO'],['NÃO É MÁGICA','ENGENHARIA','CONEXÃO','FIM']],
    'pyramid':[['PEDRAS GIGANTES','COMO?!','EGITO ANTIGO','HISTÓRIA'],['EQUIPES','PLANEJAMENTO','TRABALHO','ORGANIZAÇÃO'],['BLOCOS','TRANSPORTE','ARRASTANDO','ESFORÇO'],['RAMPAS','SUBINDO','ENGENHARIA','CONSTRUÇÃO'],['GEOMETRIA','PRECISÃO','MEDIDAS','TRABALHO'],['PESSOAS','CONSTRUÍRAM','HISTÓRIA','FIM']]}
    custom=sc.get('visual_labels')
    if isinstance(custom,list) and len(custom)==4 and all(isinstance(v,str) and 1<=len(v)<=36 for v in custom):
        caption=custom[shot%4].upper()
    else:
        caption=labels[art][ix][shot%4]
    rr(d,(286,449,674,513),'#ffffff',18,COL['ink'],3)
    bb=d.textbbox((0,0),caption,font=f(23));text(d,((W-(bb[2]-bb[0]))/2,462),caption,23)
    # small scene index and subtle motion marker
    for k in range(4):ell(d,(433+k*26,524,440+k*26,531),'#3e9eaa' if k==shot else '#d0dbe0',None)
    return im

def ffprobe_duration(probe,path):
    x=subprocess.check_output([probe,'-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)],text=True)
    return float(x.strip())
def test_voice(script,path):
    # Diagnostics only; release mode refuses silent narration.
    sec=max(6,min(30,len(script.split())*.34))
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i','anullsrc=channel_layout=mono:sample_rate=22050','-t',str(sec),'-c:a','pcm_s16le',str(path)],check=True)
def piper_voice(piper,model,script,path):
    p=subprocess.run([piper,'--model',model,'--output_file',str(path)],input=script,encoding='utf-8',errors='replace',capture_output=True,text=True,timeout=600)
    if p.returncode:raise RuntimeError('Falha na voz local: '+p.stderr[-800:])
    if not path.exists() or path.stat().st_size<5000:raise RuntimeError('Narração vazia')
    with wave.open(str(path),'rb') as wf:
        sm=wf.readframes(min(wf.getnframes(),wf.getframerate()*2))
        import array
        z=array.array('h');z.frombytes(sm[:len(sm)//2*2]);
        if max((abs(v) for v in z),default=0)<80:raise RuntimeError('Narração sem áudio audível')
def stamp(sec):
    h=int(sec//3600);m=int((sec%3600)//60);s=sec%60
    return f'{h:02}:{m:02}:{s:06.3f}'.replace('.',',')
def music(path):
    sr=16000;dur=6
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr)
        buf=bytearray()
        for i in range(sr*dur):
            t=i/sr;beat=(int(t*2)%4);f0=[165,196,220,196][beat];env=(.5+.5*math.cos(t*math.tau/3))
            v=.7*math.sin(t*math.tau*f0)+.14*math.sin(t*math.tau*f0*1.5)
            buf+=struct.pack('<h',int(1900*v*env))
        w.writeframes(buf)
def event(msg,pct):print(json.dumps({'message':msg,'pct':pct},ensure_ascii=False),flush=True)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--story',required=True);ap.add_argument('--output',required=True);ap.add_argument('--piper',default='');ap.add_argument('--model',default='');ap.add_argument('--ffmpeg',default='ffmpeg');ap.add_argument('--ffprobe',default='ffprobe');ap.add_argument('--quality',choices=['720','1080'],default='720');ap.add_argument('--test',action='store_true');ap.add_argument('--limit',type=int,default=0)
    a=ap.parse_args();st=json.loads(Path(a.story).read_text('utf8'));out=Path(a.output);out.mkdir(parents=True,exist_ok=True);work=out/'producao';work.mkdir(exist_ok=True)
    scenes=st['scenes'][:a.limit or None];fps=12;clips=[];subs=[];offset=0
    for ix,sc in enumerate(scenes):
        wav=work/f'voz_{ix:02}.wav'
        if not wav.exists() or wav.stat().st_size<4000:
            if a.test:test_voice(sc['script'],wav)
            else:piper_voice(a.piper,a.model,sc['script'],wav)
        d=ffprobe_duration(a.ffprobe,wav);duration=d+1.15
        # all 4 shots are bespoke variants; 12fps artistic animation converted to 24fps final
        pieces=[]
        for sh in range(4):
            seg=work/f'{ix:02}_{sh}.mp4';shotdur=duration/4
            if not seg.exists() or seg.stat().st_size<6000:
                count=math.ceil(shotdur*fps)
                targetw,targeth=(1920,1080) if a.quality=='1080' else (1280,720)
                cmd=[a.ffmpeg,'-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(fps),'-i','-','-vf',f'scale={targetw}:{targeth}:flags=bicubic,fps=24,format=yuv420p','-an','-c:v','libx264','-preset','veryfast','-crf','23','-movflags','+faststart',str(seg)]
                with subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE) as p:
                    try:
                        for j in range(count):
                            u=j/max(1,count-1)
                            frame=layout(st,sc,ix,sh,u)
                            p.stdin.write(frame.tobytes())
                        p.stdin.close();err=p.stderr.read();ret=p.wait()
                        if ret:raise RuntimeError('Falha FFmpeg ao animar: '+err.decode(errors='replace')[-500:])
                    except Exception:
                        p.kill();p.wait();raise
            pieces.append(seg)
        concat=work/f'c_{ix}.txt'
        concat.write_text(''.join("file '"+p.as_posix().replace("'","'\\''")+"'\n" for p in pieces),'utf8')
        video=work/f'c_{ix}.mp4'
        subprocess.run([a.ffmpeg,'-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(wav),'-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','128k','-shortest',str(video)],check=True)
        clips.append(video)
        phrases=re.split(r'(?<=[.!?])\s+',sc['script']);total=sum(max(1,len(p)) for p in phrases);pos=offset
        for phrase in phrases:
            end=pos+d*max(1,len(phrase))/total;subs.append((pos,end,phrase));pos=end
        offset+=ffprobe_duration(a.ffprobe,video)
        event(f'Capítulo {ix+1}/{len(scenes)} animado — 4 cenas encenadas',int(4+80*(ix+1)/len(scenes)))
    concat=work/'final_list.txt';concat.write_text(''.join("file '"+p.as_posix().replace("'","'\\''")+"'\n" for p in clips),'utf8')
    joined=work/'joined.mp4'
    subprocess.run([a.ffmpeg,'-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat),'-c','copy',str(joined)],check=True)
    bg=work/'trilha.wav';music(bg)
    final=out/(st['id']+'_animado_2d.mp4')
    subprocess.run([a.ffmpeg,'-hide_banner','-loglevel','error','-y','-i',str(joined),'-stream_loop','-1','-i',str(bg),'-filter_complex','[1:a]volume=0.075[bg];[0:a][bg]amix=inputs=2:duration=first[a]','-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-b:a','160k','-shortest','-movflags','+faststart',str(final)],check=True)
    t=layout(st,scenes[0],0,0,.3);t.resize((1280,720),Image.Resampling.LANCZOS).save(out/(st['id']+'_miniatura.jpg'),quality=91)
    lines=[]
    for i,(a1,b1,caption) in enumerate(subs):lines.extend([str(i+1),stamp(a1)+' --> '+stamp(b1),caption,''])
    (out/(st['id']+'_legendas.srt')).write_text('\n'.join(lines),'utf8')
    (out/(st['id']+'_youtube.txt')).write_text(st['topic']+'\n\nUma curiosidade explicada com animações 2D originais e humor leve.\n\n#Curiosidades #Aprendizado #Ciência\n','utf8')
    actual=ffprobe_duration(a.ffprobe,final)
    if abs(actual-offset)>5:raise RuntimeError(f'Erro de duração: {actual:.1f}s x {offset:.1f}s')
    if not a.test and final.stat().st_size<100000:raise RuntimeError('Vídeo final inesperadamente pequeno')
    event(f'Pronto: vídeo com {len(scenes)*4} cenas encenadas, {actual:.0f} segundos',100)
    print(json.dumps({'done':True,'path':str(final),'duration':round(actual,1)},ensure_ascii=False),flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps({'error':str(e)},ensure_ascii=False),flush=True);sys.exit(2)
