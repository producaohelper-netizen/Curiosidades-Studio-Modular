import json,sys,argparse
from pathlib import Path
from render import layout
p=argparse.ArgumentParser();p.add_argument('--story',required=True);p.add_argument('--output',required=True);a=p.parse_args()
st=json.loads(Path(a.story).read_text(encoding='utf8'))
if len(st['scenes'])!=6:raise ValueError('São necessários seis capítulos')
out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
for i,sc in enumerate(st['scenes']):
    for sh in range(4):
        frame=layout(st,sc,i,sh,.42)
        target=out/f'capitulo_{i+1:02d}_tomada_{sh+1:02d}.png'
        frame.save(target)
    print(f'Capítulo {i+1}/6: quatro desenhos salvos',flush=True)
print('Prévias prontas. Cada imagem permite inspecionar o visual antes da narração.',flush=True)
