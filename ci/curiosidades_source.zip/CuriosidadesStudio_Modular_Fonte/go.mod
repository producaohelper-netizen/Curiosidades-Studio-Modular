module curiosidadesmodular

go 1.22
