package main

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode"
)

//go:embed assets/*
var assets embed.FS
var stage = "1"
var client = &http.Client{Timeout: 4 * time.Minute}

type Trend struct {
	Title     string   `json:"titulo"`
	Traffic   string   `json:"buscas"`
	Link      string   `json:"link"`
	Published string   `json:"publicado"`
	Articles  []string `json:"artigos,omitempty"`
	Score     int      `json:"pontuacao,omitempty"`
}
type Trends struct {
	Collected string  `json:"coletado"`
	Source    string  `json:"fonte"`
	Items     []Trend `json:"top5"`
}
type Selection struct {
	Trend  Trend  `json:"tendencia"`
	Theme  string `json:"tema"`
	Reason string `json:"criterio"`
}
type Scene struct {
	Headline string `json:"headline"`
	Tag      string `json:"tag"`
	Script   string `json:"script"`
}
type Story struct {
	ID       string   `json:"id"`
	Topic    string   `json:"topic"`
	Category string   `json:"category"`
	Tags     []string `json:"tags"`
	Accent   string   `json:"accent"`
	Art      string   `json:"art"`
	Scenes   []Scene  `json:"scenes"`
}

var root string

func fatal(e error) {
	fmt.Fprintln(os.Stderr, "\nERRO:", e)
	fmt.Println("\nOs arquivos anteriores foram preservados. Pressione ENTER para fechar.")
	var s string
	fmt.Scanln(&s)
	os.Exit(1)
}
func out(s string, a ...any) { fmt.Printf(s+"\n", a...) }
func path(s string) string   { return filepath.Join(root, s) }
func makeDir(p string) error { return os.MkdirAll(p, 0755) }
func writeJSON(name string, v any) error {
	b, e := json.MarshalIndent(v, "", "  ")
	if e != nil {
		return e
	}
	return os.WriteFile(path(name), b, 0644)
}
func readJSON(name string, v any) error {
	b, e := os.ReadFile(path(name))
	if e != nil {
		return fmt.Errorf("arquivo %s ausente; execute a etapa anterior: %w", name, e)
	}
	return json.Unmarshal(b, v)
}
func download(url, target string) error {
	if st, e := os.Stat(target); e == nil && st.Size() > 1000 {
		return nil
	}
	if e := makeDir(filepath.Dir(target)); e != nil {
		return e
	}
	var offset int64
	part := target + ".part"
	if st, e := os.Stat(part); e == nil {
		offset = st.Size()
	}
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("User-Agent", "CuriosidadesModular/1.0")
	if offset > 0 {
		req.Header.Set("Range", fmt.Sprintf("bytes=%d-", offset))
	}
	res, e := client.Do(req)
	if e != nil {
		return e
	}
	defer res.Body.Close()
	if res.StatusCode != 200 && res.StatusCode != 206 {
		return fmt.Errorf("download HTTP %d: %s", res.StatusCode, url)
	}
	var f *os.File
	if res.StatusCode == 206 {
		f, e = os.OpenFile(part, os.O_WRONLY|os.O_APPEND, 0644)
	} else {
		f, e = os.Create(part)
	}
	if e != nil {
		return e
	}
	n, e := io.Copy(f, io.LimitReader(res.Body, 850*1024*1024))
	ce := f.Close()
	if e != nil {
		return e
	}
	if ce != nil {
		return ce
	}
	if n < 100 {
		return errors.New("download incompleto")
	}
	return os.Rename(part, target)
}
func unzip(z, target string) error {
	r, e := zip.OpenReader(z)
	if e != nil {
		return e
	}
	defer r.Close()
	if e = makeDir(target); e != nil {
		return e
	}
	for _, f := range r.File {
		n := filepath.Clean(f.Name)
		if filepath.IsAbs(n) || strings.HasPrefix(n, "..") || strings.Contains(n, ":") {
			return errors.New("zip inseguro")
		}
		dst := filepath.Join(target, n)
		if f.FileInfo().IsDir() {
			makeDir(dst)
			continue
		}
		makeDir(filepath.Dir(dst))
		in, e := f.Open()
		if e != nil {
			return e
		}
		out, e := os.Create(dst)
		if e != nil {
			in.Close()
			return e
		}
		_, e = io.Copy(out, in)
		in.Close()
		out.Close()
		if e != nil {
			return e
		}
	}
	return nil
}
func find(dir, n string) string {
	var result string
	filepath.Walk(dir, func(p string, i os.FileInfo, e error) error {
		if result == "" && e == nil && i != nil && !i.IsDir() && strings.EqualFold(i.Name(), n) {
			result = p
		}
		return nil
	})
	return result
}
func command(name string, args ...string) error {
	c := exec.Command(name, args...)
	c.Dir = root
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	return c.Run()
}
func deps(needPiper bool) (py, ffmpeg, piper, model string, e error) {
	if runtime.GOOS != "windows" {
		py = "python3"
		ffmpeg = "ffmpeg"
		piper = "piper"
		return
	}
	tools := path("ferramentas")
	makeDir(tools)
	uv := find(filepath.Join(tools, "uv"), "uv.exe")
	if uv == "" {
		out("Preparando ambiente Python (primeira execução)...")
		zipfile := filepath.Join(tools, "uv.zip")
		if e = download("https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip", zipfile); e != nil {
			return
		}
		if e = unzip(zipfile, filepath.Join(tools, "uv")); e != nil {
			return
		}
		uv = find(filepath.Join(tools, "uv"), "uv.exe")
	}
	if uv == "" {
		e = errors.New("uv.exe não encontrado")
		return
	}
	py = filepath.Join(tools, "venv", "Scripts", "python.exe")
	if _, er := os.Stat(py); er != nil {
		out("Instalando Python 3.12...")
		if e = command(uv, "venv", "--python", "3.12", filepath.Join(tools, "venv")); e != nil {
			return
		}
	}
	marker := filepath.Join(tools, "pillow.ok")
	if _, er := os.Stat(marker); er != nil {
		out("Instalando biblioteca de desenho...")
		if e = command(uv, "pip", "install", "--python", py, "pillow>=11,<13"); e != nil {
			return
		}
		os.WriteFile(marker, []byte("ok"), 0644)
	}
	ffmpeg = find(filepath.Join(tools, "ffmpeg"), "ffmpeg.exe")
	if ffmpeg == "" {
		out("Baixando FFmpeg gratuito...")
		z := filepath.Join(tools, "ffmpeg.zip")
		if e = download("https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip", z); e != nil {
			return
		}
		if e = unzip(z, filepath.Join(tools, "ffmpeg")); e != nil {
			return
		}
		ffmpeg = find(filepath.Join(tools, "ffmpeg"), "ffmpeg.exe")
	}
	if ffmpeg == "" {
		e = errors.New("ffmpeg.exe ausente")
		return
	}
	if needPiper {
		piper = find(filepath.Join(tools, "piper"), "piper.exe")
		if piper == "" {
			out("Baixando narrador brasileiro Piper...")
			z := filepath.Join(tools, "piper.zip")
			if e = download("https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_windows_amd64.zip", z); e != nil {
				return
			}
			if e = unzip(z, filepath.Join(tools, "piper")); e != nil {
				return
			}
			piper = find(filepath.Join(tools, "piper"), "piper.exe")
		}
		if piper == "" {
			e = errors.New("piper.exe ausente")
			return
		}
		model = filepath.Join(tools, "voz", "pt_BR-faber-medium.onnx")
		url := "https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/pt/pt_BR/faber/medium/pt_BR-faber-medium.onnx"
		if e = download(url, model); e != nil {
			return
		}
		if e = download(url+".json", model+".json"); e != nil {
			return
		}
	}
	return
}
func ensureResources() error {
	for _, s := range []string{"render.py", "stories.json", "previews.py"} {
		b, e := assets.ReadFile("assets/" + s)
		if e != nil {
			return e
		}
		dst := path(filepath.Join("motor", s))
		makeDir(filepath.Dir(dst))
		if _, err := os.Stat(dst); err == nil {
			// Preserve user-edited scene engines and assets between stages.
			continue
		}
		if e = os.WriteFile(dst, b, 0644); e != nil {
			return e
		}
	}
	return nil
}
func stage1() error {
	out("Consultando Google Trends Brasil em tempo real...")
	req, _ := http.NewRequestWithContext(context.Background(), "GET", "https://trends.google.com/trending/rss?geo=BR", nil)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) CuriosidadesStudio/Modular")
	res, e := client.Do(req)
	if e != nil {
		return fmt.Errorf("não foi possível acessar Google Trends; conexão necessária: %w", e)
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		return fmt.Errorf("Google Trends HTTP %d", res.StatusCode)
	}
	b, e := io.ReadAll(io.LimitReader(res.Body, 3<<20))
	if e != nil {
		return e
	}
	var feed struct {
		Items []struct {
			Title   string `xml:"title"`
			Link    string `xml:"link"`
			PubDate string `xml:"pubDate"`
			Approx  string `xml:"approx_traffic"`
			News    []struct {
				Title string `xml:"news_item_title"`
				URL   string `xml:"news_item_url"`
			} `xml:"news_item"`
		} `xml:"channel>item"`
	}
	if e = xml.Unmarshal(b, &feed); e != nil {
		return fmt.Errorf("RSS mudou de formato: %w", e)
	}
	if len(feed.Items) == 0 {
		return errors.New("Google Trends retornou zero tendências; não inventei resultados")
	}
	result := Trends{Collected: time.Now().Format(time.RFC3339), Source: "https://trends.google.com/trending/rss?geo=BR"}
	for _, v := range feed.Items {
		t := Trend{Title: strings.TrimSpace(v.Title), Traffic: v.Approx, Link: v.Link, Published: v.PubDate}
		for _, n := range v.News {
			if n.Title != "" {
				t.Articles = append(t.Articles, n.Title+" — "+n.URL)
			}
		}
		if t.Title != "" {
			result.Items = append(result.Items, t)
		}
	}
	sort.SliceStable(result.Items, func(i, j int) bool {
		return trafficCount(result.Items[i].Traffic) > trafficCount(result.Items[j].Traffic)
	})
	if len(result.Items) > 5 {
		result.Items = result.Items[:5]
	}
	if len(result.Items) < 5 {
		return errors.New("RSS retornou menos de 5 tendências; evitando lista artificial")
	}
	if e = writeJSON("01_top5_google_trends.json", result); e != nil {
		return e
	}
	for i, t := range result.Items {
		out("%d. %s  (%s)", i+1, t.Title, t.Traffic)
	}
	out("Concluído: 01_top5_google_trends.json")
	return nil
}
func trafficCount(s string) float64 {
	s = strings.TrimSpace(strings.ToUpper(strings.ReplaceAll(s, ",", ".")))
	factor := 1.0
	if strings.Contains(s, "M") || strings.Contains(s, "MILH") {
		factor = 1000000
	} else if strings.Contains(s, "K") || strings.Contains(s, "MIL") {
		factor = 1000
	}
	cleaned := ""
	for _, r := range s {
		if (r >= '0' && r <= '9') || r == '.' {
			cleaned += string(r)
		} else if cleaned != "" {
			break
		}
	}
	v, _ := strconv.ParseFloat(cleaned, 64)
	return v * factor
}
func score(t Trend) int {
	s := 0
	v := strings.ToLower(t.Title)
	for _, w := range []string{"ciência", "cient", "espaço", "planeta", "lua", "sol", "eclipse", "animal", "tubar", "urso", "vulc", "terremoto", "clima", "ciclone", "chuva", "oceano", "dinossauro", "inteligência artificial", "robot", "tecnologia", "internet", "energia", "corpo", "cérebro", "história", "egito", "enigma", "mistério", "descoberta", "satélite"} {
		if strings.Contains(v, w) {
			s += 20
		}
	}
	for _, w := range []string{"morre", "morte", "assassin", "tragédia", "acidente", "vítima", "tragico", "polícia", "sequestro", "guerra", "violência", "aposta", "loteria", "cassino", "crime"} {
		if strings.Contains(v, w) {
			s -= 70
		}
	}
	if len(t.Articles) > 0 {
		s += 8
	}
	if strings.Contains(t.Traffic, "M+") {
		s += 10
	} else if strings.Contains(t.Traffic, "K+") {
		s += 5
	}
	return s
}
func stage2() error {
	var tr Trends
	if e := readJSON("01_top5_google_trends.json", &tr); e != nil {
		return e
	}
	if len(tr.Items) < 5 {
		return errors.New("lista Top 5 incompleta")
	}
	chosen := tr.Items[0]
	best := -9999
	for i, t := range tr.Items {
		sc := score(t)
		out("%d. %s — nota editorial %d", i+1, t.Title, sc)
		if sc > best {
			best = sc
			chosen = t
		}
	}
	chosen.Score = best
	if best < 0 {
		return errors.New("Nenhuma das cinco tendências é adequada para curiosidade educativa e humor. Refaça a pesquisa depois; não vou explorar tragédias.")
	}
	s := Selection{Trend: chosen, Theme: "A curiosidade por trás de: " + chosen.Title, Reason: "Assunto selecionado por pertinência educativa e segurança de conteúdo; popularidade não garante viralização."}
	if e := writeJSON("02_tema_escolhido.json", s); e != nil {
		return e
	}
	out("ESCOLHIDO: %s", chosen.Title)
	return nil
}
func onlyClean(a string) string {
	a = strings.TrimSpace(a)
	if a == "" {
		return "curiosidade"
	}
	r := []rune{}
	for _, c := range strings.ToLower(a) {
		if unicode.IsLetter(c) || unicode.IsDigit(c) {
			r = append(r, c)
		} else if len(r) > 0 && r[len(r)-1] != '-' {
			r = append(r, '-')
		}
	}
	if len(r) > 50 {
		r = r[:50]
	}
	return strings.Trim(string(r), "-")
}
func nwords(s string) int { return len(strings.Fields(s)) }
func genOllama(s Selection) (Story, error) {
	prompt := fmt.Sprintf(`Você é roteirista de YouTube para público brasileiro e crianças. Crie UMA curiosidade factual relacionada ao assunto que está em alta: %q. Manchetes RSS: %v. Não assuma como verdade rumores ou eventos em andamento; ensine um mecanismo científico ou histórico verificável e atemporal. Humor inocente e leve, natural, um narrador único, sem personagens conhecidos nem bordões. Retorne APENAS um JSON válido (sem markdown), com campos id, topic, category, tags (array de strings), accent ("#58d9ff"), art (apenas uma entre earth, octopus, lightning, brain, volcano, moon, network, pyramid), scenes (array com EXATAMENTE 6 objetos com headline, tag, script). Cada cena deve ter aproximadamente 90-120 palavras EM PORTUGUÊS, total de 570 a 720 palavras, narrativa com gancho forte, exemplo concreto, demonstração, surpresa e conclusão, nada de listas faladas ou repetir as mesmas ideias. Escolha art pelo mecanismo explicado, não pela notícia. Não afirme que o vídeo é uma notícia atual.`, s.Trend.Title, s.Trend.Articles)
	model := os.Getenv("CSTUDIO_OLLAMA_MODEL")
	if model == "" {
		model = "qwen2.5:7b"
	}
	reqBody, _ := json.Marshal(map[string]any{"model": model, "prompt": prompt, "stream": false, "format": "json", "options": map[string]any{"temperature": 0.65, "num_predict": 6000}})
	c := &http.Client{Timeout: 25 * time.Minute}
	res, e := c.Post("http://127.0.0.1:11434/api/generate", "application/json", bytes.NewReader(reqBody))
	if e != nil {
		return Story{}, fmt.Errorf("Ollama local indisponível. Instale Ollama e execute 'ollama pull %s' antes desta etapa: %w", model, e)
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		b, _ := io.ReadAll(io.LimitReader(res.Body, 2000))
		return Story{}, fmt.Errorf("Ollama HTTP %d: %s", res.StatusCode, b)
	}
	var ret struct {
		Response string `json:"response"`
		Error    string `json:"error"`
	}
	if e = json.NewDecoder(res.Body).Decode(&ret); e != nil {
		return Story{}, e
	}
	if ret.Error != "" {
		return Story{}, errors.New(ret.Error)
	}
	var story Story
	if e = json.Unmarshal([]byte(ret.Response), &story); e != nil {
		return Story{}, fmt.Errorf("IA não retornou JSON válido: %w", e)
	}
	if len(story.Scenes) != 6 {
		return Story{}, fmt.Errorf("IA produziu %d capítulos em vez de 6; execute novamente", len(story.Scenes))
	}
	total := 0
	for i, sc := range story.Scenes {
		if sc.Headline == "" || sc.Script == "" {
			return Story{}, fmt.Errorf("capítulo %d incompleto", i+1)
		}
		total += nwords(sc.Script)
	}
	if total < 450 || total > 850 {
		return Story{}, fmt.Errorf("roteiro com %d palavras fora da faixa de aproximadamente 5 minutos; execute novamente", total)
	}
	allowed := map[string]bool{"earth": true, "octopus": true, "lightning": true, "brain": true, "volcano": true, "moon": true, "network": true, "pyramid": true}
	if !allowed[story.Art] {
		return Story{}, errors.New("IA escolheu tipo de arte não suportado")
	}
	story.ID = onlyClean(s.Trend.Title)
	if story.Accent == "" {
		story.Accent = "#58d9ff"
	}
	return story, nil
}
func stage3() error {
	var sel Selection
	if e := readJSON("02_tema_escolhido.json", &sel); e != nil {
		return e
	}
	out("Criando roteiro com IA local Ollama — pode demorar na CPU...")
	story, e := genOllama(sel)
	if e != nil {
		return e
	}
	if e = writeJSON("03_roteiro.json", story); e != nil {
		return e
	}
	var b strings.Builder
	fmt.Fprintf(&b, "TEMA: %s\n\n", story.Topic)
	for i, c := range story.Scenes {
		fmt.Fprintf(&b, "CAPÍTULO %d: %s\n%s\n\n", i+1, c.Headline, c.Script)
	}
	os.WriteFile(path("03_roteiro.txt"), []byte(b.String()), 0644)
	out("Roteiro salvo com %d palavras.", nwords(b.String()))
	return nil
}
func stage4() error {
	var st Story
	if e := readJSON("03_roteiro.json", &st); e != nil {
		return e
	}
	if len(st.Scenes) != 6 {
		return errors.New("roteiro deve ter exatamente 6 capítulos")
	}
	py, _, _, _, e := deps(false)
	if e != nil {
		return e
	}
	out("Gerando 24 prévias visuais (4 por capítulo)...")
	dst := path("04_cenas")
	makeDir(dst)
	e = command(py, path(filepath.Join("motor", "previews.py")), "--story", path("03_roteiro.json"), "--output", dst)
	if e != nil {
		return e
	}
	out("Concluído: 04_cenas (24 imagens PNG)")
	return nil
}
func signature(s string) string { h := sha256.Sum256([]byte(s)); return hex.EncodeToString(h[:]) }
func stage5() error {
	var st Story
	if e := readJSON("03_roteiro.json", &st); e != nil {
		return e
	}
	if len(st.Scenes) != 6 {
		return errors.New("roteiro inválido")
	}
	_, _, piper, model, e := deps(true)
	if e != nil {
		return e
	}
	wavdir := path("05_audios")
	makeDir(wavdir)
	for i, sc := range st.Scenes {
		wav := filepath.Join(wavdir, fmt.Sprintf("voz_%02d.wav", i))
		sigfile := wav + ".texto.sha256"
		existingSig, _ := os.ReadFile(sigfile)
		if stat, e := os.Stat(wav); e == nil && stat.Size() > 4000 && string(existingSig) == signature(sc.Script) {
			out("%d/6: voz reaproveitada", i+1)
			continue
		}
		out("%d/6: narrando...", i+1)
		cmd := exec.Command(piper, "--model", model, "--output_file", wav)
		cmd.Stdin = strings.NewReader(sc.Script)
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr
		if e = cmd.Run(); e != nil {
			return fmt.Errorf("falha na voz %d: %w", i+1, e)
		}
		if e = os.WriteFile(sigfile, []byte(signature(sc.Script)), 0644); e != nil {
			return e
		}
		stat, e := os.Stat(wav)
		if e != nil || stat.Size() < 4000 {
			return fmt.Errorf("áudio %d não foi criado corretamente", i+1)
		}
	}
	out("6 arquivos WAV criados em 05_audios. Escute antes da montagem.")
	return nil
}
func stage6() error {
	var story Story
	if e := readJSON("03_roteiro.json", &story); e != nil {
		return e
	}
	for i := range story.Scenes {
		f := path(filepath.Join("05_audios", fmt.Sprintf("voz_%02d.wav", i)))
		if st, e := os.Stat(f); e != nil || st.Size() < 4000 {
			return fmt.Errorf("voz %d ausente; execute etapa 05", i+1)
		}
		sig, _ := os.ReadFile(f + ".texto.sha256")
		if string(sig) != signature(story.Scenes[i].Script) {
			return fmt.Errorf("voz %d não corresponde ao roteiro atual; execute etapa 05", i+1)
		}
	}
	py, ffmpeg, _, _, e := deps(false)
	if e != nil {
		return e
	}
	ffprobe := ffmpeg
	if runtime.GOOS == "windows" {
		ffprobe = find(filepath.Dir(filepath.Dir(ffmpeg)), "ffprobe.exe")
		if ffprobe == "" {
			ffprobe = find(path("ferramentas"), "ffprobe.exe")
		}
	} else {
		ffprobe = "ffprobe"
	}
	if ffprobe == "" {
		return errors.New("ffprobe não encontrado")
	}
	dst := path("06_video_final")
	makeDir(dst)
	work := filepath.Join(dst, "producao")
	makeDir(work)
	for i := range story.Scenes {
		source := path(filepath.Join("05_audios", fmt.Sprintf("voz_%02d.wav", i)))
		target := filepath.Join(work, fmt.Sprintf("voz_%02d.wav", i))
		b, e := os.ReadFile(source)
		if e != nil {
			return e
		}
		if e = os.WriteFile(target, b, 0644); e != nil {
			return e
		}
	}
	out("Renderizando e sincronizando 24 cenas. Esta operação pode demorar...")
	args := []string{path(filepath.Join("motor", "render.py")), "--story", path("03_roteiro.json"), "--output", dst, "--ffmpeg", ffmpeg, "--ffprobe", ffprobe, "--quality", "720"}
	if e = command(py, args...); e != nil {
		return fmt.Errorf("falha na renderização: %w", e)
	}
	mp4 := filepath.Join(dst, story.ID+"_animado_2d.mp4")
	if _, e := os.Stat(mp4); e != nil {
		return fmt.Errorf("MP4 final ausente: %w", e)
	}
	cmd := exec.Command(ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", mp4)
	raw, e := cmd.Output()
	if e != nil {
		return fmt.Errorf("não foi possível verificar duração: %w", e)
	}
	dur, e := strconv.ParseFloat(strings.TrimSpace(string(raw)), 64)
	if e != nil {
		return e
	}
	if os.Getenv("CSTUDIO_TEST_SHORT") != "1" && (dur < 270 || dur > 330) {
		return fmt.Errorf("vídeo renderizado tem %.0fs, fora de 5 minutos (aceito 4m30 a 5m30); ajuste 03_roteiro.json e refaça etapas 05 e 06. MP4 salvo para inspeção, mas NÃO aprovado", dur)
	}
	out("Duração verificada: %.0fs", dur)
	out("MP4, miniatura e legendas em 06_video_final. Confira o resultado antes de publicar.")
	return nil
}
func main() {
	fmt.Println("======================================================")
	fmt.Println(" CURIOSIDADES STUDIO — ETAPA", stage, "/ 6")
	fmt.Println("======================================================")
	base, _ := os.Executable()
	root = filepath.Join(filepath.Dir(base), "PROJETO")
	if s := os.Getenv("CSTUDIO_ROOT"); s != "" {
		root = s
	}
	if e := makeDir(root); e != nil {
		fatal(e)
	}
	if e := ensureResources(); e != nil {
		fatal(e)
	}
	var e error
	switch stage {
	case "1":
		e = stage1()
	case "2":
		e = stage2()
	case "3":
		e = stage3()
	case "4":
		e = stage4()
	case "5":
		e = stage5()
	case "6":
		e = stage6()
	default:
		e = errors.New("etapa desconhecida")
	}
	if e != nil {
		fatal(e)
	}
	fmt.Println("\nSUCESSO. Pasta do projeto:", root)
	fmt.Println("Pressione ENTER para fechar.")
	var s string
	fmt.Scanln(&s)
	// used to ensure imports remain stable and selectable build stages are available
}
