# Curiosidades Studio - Etapa 03 (codigo aberto, somente biblioteca padrao Python)
# Nao baixa nem executa programas externos. Usa Ollama local existente.
import json, os, pathlib, sys, urllib.request, urllib.error, re, time, socket

HERE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path(os.environ.get('CSTUDIO_ROOT', str(HERE / 'PROJETO')))
BASE = 'http://127.0.0.1:11434'
MODEL = os.environ.get('CSTUDIO_OLLAMA_MODEL', 'qwen2.5:7b')
ART = {'earth','octopus','lightning','brain','volcano','moon','network','pyramid'}

def get(path):
    with urllib.request.urlopen(BASE + path, timeout=6) as r:
        return json.load(r)

def generate(prompt):
    # Ollama em streaming: permite visualizar a atividade da IA sem expor o texto bruto.
    data = json.dumps({
        'model': MODEL, 'prompt': prompt, 'stream': True, 'format': 'json',
        'options': {'temperature': 0.55, 'num_predict': 5500, 'num_ctx': 4096}
    }, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(BASE + '/api/generate', data=data,
        headers={'Content-Type': 'application/json'}, method='POST')
    started=time.monotonic()
    last_notice=started
    assembled=[]
    chunks=0
    try:
        # Intervalo de inatividade por resposta, nao tempo total do roteiro.
        with urllib.request.urlopen(req, timeout=150) as r:
            while True:
                raw=r.readline()
                if not raw:
                    break
                item=json.loads(raw.decode('utf-8'))
                if item.get('error'):
                    raise RuntimeError('Ollama: '+str(item['error']))
                piece=item.get('response','')
                assembled.append(piece)
                chunks += 1
                now=time.monotonic()
                if now-last_notice >= 12:
                    print(f'IA trabalhando: {int(now-started)}s, {len("".join(assembled))} caracteres recebidos...', flush=True)
                    last_notice=now
                if now-started > 1200:
                    raise TimeoutError('Geracao ultrapassou 20 minutos. Nenhum roteiro anterior foi alterado.')
                if item.get('done'):
                    break
    except (TimeoutError, socket.timeout) as e:
        raise RuntimeError('Ollama ficou sem responder por tempo excessivo. Verifique RAM e CPU; tente novamente. '+str(e)) from e
    content=''.join(assembled)
    if not content.strip():
        raise RuntimeError('Ollama respondeu sem texto; confira se o modelo esta carregado e tem memoria livre.')
    print(f'Resposta recebida: {len(content)} caracteres em {time.monotonic()-started:.0f}s. Validando...',flush=True)
    try:
        return json.loads(content)
    except json.JSONDecodeError as e:
        # Arquivo de diagnostico para permitir correcoes sem gerar tudo de novo.
        ROOT.mkdir(parents=True, exist_ok=True)
        (ROOT/'03_resposta_invalida.txt').write_text(content, encoding='utf-8')
        raise RuntimeError('A IA retornou JSON invalido. Conteudo salvo em PROJETO/03_resposta_invalida.txt: '+str(e)) from e

def validate(s, title):
    if not isinstance(s,dict) or not isinstance(s.get('scenes'),list) or len(s['scenes'])!=6:
        raise ValueError('Roteiro deve conter exatamente 6 capitulos em scenes')
    if s.get('art') not in ART:
        raise ValueError('Arte escolhida fora dos 8 modelos suportados pela etapa 04: '+str(s.get('art')))
    total=0
    for i,scene in enumerate(s['scenes'],1):
        if not isinstance(scene,dict) or not all(isinstance(scene.get(k),str) and scene[k].strip() for k in ('headline','tag','script')):
            raise ValueError('Capitulo '+str(i)+' incompleto (headline/tag/script)')
        total+=len(scene['script'].split())
    if total<450 or total>850:
        raise ValueError('Roteiro com '+str(total)+' palavras; esperado de 450 a 850. Tente outra geracao.')
    # Para compatibilidade, gera slug semelhante ao app Go original.
    slug=re.sub(r'[^\w\d]+','-', title.lower(),flags=re.UNICODE).strip('-')[:50].strip('-') or 'curiosidade'
    s['id']=slug
    s.setdefault('accent','#58d9ff')
    s.setdefault('tags',[])
    s.setdefault('category','curiosidades')
    s.setdefault('topic',title)
    return s,total

def main():
    print('CURIOSIDADES STUDIO - ETAPA 03 / ROTEIRO - FONTE ABERTA')
    print('Nenhum programa sera instalado automaticamente. Pasta:',ROOT)
    sel_path=ROOT/'02_tema_escolhido.json'
    if not sel_path.exists():
        raise RuntimeError('Nao encontrei PROJETO/02_tema_escolhido.json. Coloque este .py na pasta dos seis executaveis.')
    sel=json.loads(sel_path.read_text(encoding='utf-8-sig'))
    trend=sel.get('tendencia',{})
    title=trend.get('titulo') or sel.get('tema')
    if not isinstance(title,str) or not title.strip():
        raise RuntimeError('Tema nao encontrado no arquivo da etapa 02.')
    try:
        tags=get('/api/tags')
    except Exception as exc:
        raise RuntimeError('Ollama nao esta respondendo. Instale e abra pelo site oficial https://ollama.com/download/windows ; depois execute no Terminal: ollama pull '+MODEL+' . Detalhe: '+str(exc)) from exc
    models={v for m in tags.get('models',[]) for v in (m.get('name'),m.get('model'))}
    if MODEL not in models:
        raise RuntimeError('O modelo '+MODEL+' ainda nao esta instalado. Execute no Terminal: ollama pull '+MODEL)
    print('Ollama detectado. Modelo:',MODEL,'| Assunto:',title,flush=True)
    prompt=(f'Voce e roteirista de YouTube brasileiro para publico geral e criancas. Crie UMA curiosidade verdadeira e atemporal relacionada a {title!r}. '
     f'Manchetes de contexto: {trend.get("artigos",[])}. Nao invente acontecimentos atuais ou numeros. Humor inocente, um narrador unico, linguagem simples. '
     'Retorne APENAS JSON valido com: id, topic, category, tags (array), accent (cor hexadecimal), art (EXATAMENTE um dentre '
     'earth, octopus, lightning, brain, volcano, moon, network, pyramid), scenes (EXATAMENTE 6 objetos com headline, tag, script, visual_kind). Para arte earth, visual_kind deve ser rotation, inertia, ocean, day ou slow de acordo com o TEXTO DE CADA CAPITULO. Para outros arts use visual_kind vazio. visual_labels e um array de EXATAMENTE quatro frases curtas (2 a 4 palavras cada), que descrevem o que acontece nas quatro tomadas sem contrariar o texto. Nunca ponha o mesmo tipo de cena em todos os capitulos quando houver assuntos diferentes. '
     'Cada script com cerca de 90 a 120 palavras; total de 570 a 720 palavras. Gancho rapido, explicacao visual, exemplo simples, surpresa, humor moderado e conclusao. '
     'Escolha a categoria art pela explicacao, nao pelo assunto na noticia. Sem listas recitadas nem promessas falsas.')
    print('Gerando roteiro com acompanhamento de progresso. Em CPU, pode demorar varios minutos.',flush=True)
    story,total=validate(generate(prompt),title)
    ROOT.mkdir(parents=True, exist_ok=True)
    json_path=ROOT/'03_roteiro.json'
    text_path=ROOT/'03_roteiro.txt'
    temp=json_path.with_suffix('.json.tmp')
    temp.write_text(json.dumps(story,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(temp,json_path)
    lines=['TEMA: '+story['topic'],'']
    for i,sc in enumerate(story['scenes'],1):
        lines.extend([f'CAPITULO {i}: {sc["headline"]}',sc['script'],''])
    text_path.write_text('\n'.join(lines),encoding='utf-8')
    print('SUCESSO:',total,'palavras. Gerados:',json_path.name, 'e',text_path.name)
    print('Agora pode executar 04_Gerar_Cenas.exe')

if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        print('\nERRO:',exc,file=sys.stderr)
        print('Os arquivos anteriores foram preservados.',file=sys.stderr)
        sys.exit(1)
